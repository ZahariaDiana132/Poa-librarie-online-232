package produse;

public class Examen extends Manual {
    private String denumire;
    public Examen(){}
    public Examen(String denumire)
    {this.denumire=denumire;}
    public String getDenumire(){return this.denumire;}
    public void setDenumire(String denumire){this.denumire=denumire;}
    @Override
    public String toString()
    {
        return  this.getNume() + ", editura " + this.getEditura() + "materia: "
                + this.getMaterie()+ " pregatire pentru examenul " + this.denumire +
        "\n nr produsului: " + this.getNr()+  "\nPretul: " + this.getPret() + " lei";
    }
}
