package produse;

public class Seriic extends Carte {
    private int nrvolum;

   public Seriic(){}
   public Seriic(int nrvolum)
   {this.nrvolum=nrvolum;}
    public int getNrvolum(){return this.nrvolum;}
    public void setNrvolum(int nrvolum){this.nrvolum = nrvolum;}
    @Override
    public String toString()
    {
        return "Cartea de copii scrisa de " + this.getAutor() + " cu numele: " + this.getNume() + " sectia: " + this.getSect()+
                " sub-sectia: "+ this.getSubsect() + "editura: " +this.getEditura() + "volumul: " + this.nrvolum+
      "\n nr produsului: " + this.getNr()+"\n Pret: " + this.getPret() + " lei";
    }
}
