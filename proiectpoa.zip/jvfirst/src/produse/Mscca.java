package produse;

public class Mscca extends Manual{
   private int nivel;
   public Mscca(){}
   public Mscca(int nivel)
   {this.nivel=nivel;}
    public int getNivel(){return this.nivel;}
    public void setNivel(int nivel){this.nivel = nivel;}
    @Override
    public String toString()
    {
        return  this.getNume() + ", editura " + this.getEditura() + "materia: "+ "\n nr produsului: "
         + this.getNr()+this.getMaterie()+ " nivelul academic " + this.nivel + "\nPretul: " + this.getPret() + " lei";
    }


}
