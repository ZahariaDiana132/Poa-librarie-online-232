package produse;

public class Carticopii extends Carte{
    private int varstarec;
   public Carticopii(){}
    public Carticopii(int varstarec)
    {this.varstarec=varstarec;}
    public int getVarstarec(){return this.varstarec;}
    public void setVarstarec(int varstarec){this.varstarec = varstarec;}
    @Override
    public String toString()
    {
        return "Cartea de copii scrisa de " + this.getAutor() + " cu numele: " + this.getNume() + " sectia: " + this.getSect()+
                " sub-sectia: "+ this.getSubsect() + "editura: " +this.getEditura() + "limita de varsta: " + this.varstarec+
                "\n nr produsului: " + this.getNr()+  "\n Pret: " + this.getPret() + " lei";
    }
}
