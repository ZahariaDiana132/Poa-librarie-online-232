package produse;

public class Olco extends Manual{
  private String numc;
  private int etapa;
  public Olco(){}
  public Olco(String numc, int etapa)
  {this.numc=numc;
  this.etapa=etapa;}
    public int getEtapa(){return this.etapa;}
    public void setEtapa(int etapa){this.etapa = etapa;}
    public String getNumc(){return this.numc;}
    public void setNumc(String numc){this.numc= numc;}
    @Override
    public String toString()
    {
        return  this.getNume() + ", editura " + this.getEditura() + "materia: "+ this.getMaterie()+ " concursul " + this.numc + " etapa " + this.etapa +"\n nr produsului: "
                + this.getNr()+ "\nPretul: " + this.getPret() + " lei";
    }

}
